import React from 'react';
import { motion } from 'framer-motion';
import { Brain } from 'lucide-react';
import { mockQuestions } from './mockData';

interface ExamIntroProps {
  onStart: () => void;
}

export function ExamIntro({ onStart }: ExamIntroProps) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="bg-white rounded-xl shadow-lg p-8 max-w-4xl mx-auto"
    >
      <div className="text-center mb-8">
        <Brain className="w-16 h-16 text-indigo-600 mx-auto mb-4" />
        <h2 className="text-3xl font-bold mb-4">UPSC Mock Examination</h2>
        <p className="text-gray-600 mb-6">
          This is a simulated UPSC examination environment. You will have 2 hours to complete the exam.
        </p>
      </div>

      <div className="bg-indigo-50 rounded-lg p-6 mb-8">
        <h3 className="font-semibold mb-4">Exam Guidelines:</h3>
        <ul className="space-y-2 text-gray-700">
          <li>• Total duration: 2 hours</li>
          <li>• Number of questions: {mockQuestions.length}</li>
          <li>• All questions are multiple choice</li>
          <li>• No negative marking</li>
          <li>• Timer will start once you begin</li>
        </ul>
      </div>

      <button
        onClick={onStart}
        className="w-full bg-indigo-600 text-white py-3 rounded-lg hover:bg-indigo-700 transition-colors font-semibold"
      >
        Start Exam
      </button>
    </motion.div>
  );
}