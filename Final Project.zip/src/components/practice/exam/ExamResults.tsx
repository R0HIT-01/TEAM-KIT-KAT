import React from 'react';
import { motion } from 'framer-motion';
import { CheckCircle, XCircle } from 'lucide-react';
import { Question } from './types';

interface ExamResultsProps {
  questions: Question[];
  selectedAnswers: number[];
  onRetake: () => void;
}

export function ExamResults({ questions, selectedAnswers, onRetake }: ExamResultsProps) {
  const score = selectedAnswers.reduce((acc, answer, index) => {
    return acc + (answer === questions[index].correct_answer ? 1 : 0);
  }, 0);
  const percentage = (score / questions.length) * 100;

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="bg-white rounded-xl shadow-lg p-8 max-w-4xl mx-auto"
    >
      <div className="text-center mb-8">
        {percentage >= 60 ? (
          <CheckCircle className="w-16 h-16 text-green-600 mx-auto mb-4" />
        ) : (
          <XCircle className="w-16 h-16 text-red-600 mx-auto mb-4" />
        )}
        <h2 className="text-3xl font-bold mb-4">Exam Completed</h2>
        <div className="text-5xl font-bold mb-4 text-indigo-600">
          {percentage.toFixed(1)}%
        </div>
        <p className="text-gray-600">
          You answered {score} out of {questions.length} questions correctly
        </p>
      </div>

      <div className="space-y-6">
        {questions.map((question, index) => (
          <div
            key={question.id}
            className={`p-6 rounded-lg ${
              selectedAnswers[index] === question.correct_answer
                ? 'bg-green-50 border border-green-200'
                : 'bg-red-50 border border-red-200'
            }`}
          >
            <p className="font-medium mb-4">{question.text}</p>
            <div className="grid grid-cols-1 gap-2 mb-4">
              {question.options.map((option, optionIndex) => (
                <div
                  key={optionIndex}
                  className={`p-3 rounded-lg ${
                    optionIndex === question.correct_answer
                      ? 'bg-green-100 text-green-800'
                      : optionIndex === selectedAnswers[index]
                      ? 'bg-red-100 text-red-800'
                      : 'bg-white'
                  }`}
                >
                  {option}
                </div>
              ))}
            </div>
            <div className="text-sm text-gray-600">
              <strong>Explanation:</strong> {question.explanation}
            </div>
          </div>
        ))}
      </div>

      <button
        onClick={onRetake}
        className="w-full mt-8 bg-indigo-600 text-white py-3 rounded-lg hover:bg-indigo-700 transition-colors font-semibold"
      >
        Take Another Exam
      </button>
    </motion.div>
  );
}