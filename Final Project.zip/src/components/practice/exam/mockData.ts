import { Question } from './types';

export const mockQuestions: Question[] = [
  {
    id: '1',
    text: 'Which of the following is NOT a Fundamental Right guaranteed by the Indian Constitution?',
    options: [
      'Right to Equality',
      'Right to Property',
      'Right to Freedom of Religion',
      'Right to Constitutional Remedies'
    ],
    correct_answer: 1,
    explanation: 'Right to Property was originally a Fundamental Right under Article 31 but was removed by the 44th Amendment in 1978. It is now a legal right under Article 300A.',
    difficulty: 'medium',
    subject: 'Indian Polity',
    topic: 'Fundamental Rights'
  },
  {
    id: '2',
    text: 'The concept of Directive Principles of State Policy was borrowed from which constitution?',
    options: [
      'British Constitution',
      'US Constitution',
      'Irish Constitution',
      'Canadian Constitution'
    ],
    correct_answer: 2,
    explanation: 'The concept of Directive Principles of State Policy was borrowed from the Irish Constitution of 1937.',
    difficulty: 'medium',
    subject: 'Indian Polity',
    topic: 'DPSP'
  }
];