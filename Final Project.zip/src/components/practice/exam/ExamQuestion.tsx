import React from 'react';
import { Clock } from 'lucide-react';
import { Question } from './types';
import { formatTime } from './utils';

interface ExamQuestionProps {
  question: Question;
  questionNumber: number;
  totalQuestions: number;
  selectedAnswer?: number;
  timeLeft: number;
  onAnswerSelect: (index: number) => void;
  onNext: () => void;
  onPrevious: () => void;
  onSubmit: () => void;
}

export function ExamQuestion({
  question,
  questionNumber,
  totalQuestions,
  selectedAnswer,
  timeLeft,
  onAnswerSelect,
  onNext,
  onPrevious,
  onSubmit,
}: ExamQuestionProps) {
  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center mb-6">
        <div className="flex items-center gap-4">
          <span className="text-lg font-semibold">
            Question {questionNumber}/{totalQuestions}
          </span>
          <span className="px-3 py-1 bg-indigo-100 text-indigo-800 rounded-full text-sm">
            {question.subject}
          </span>
        </div>
        <div className="flex items-center gap-2 text-gray-600">
          <Clock className="w-5 h-5" />
          <span className="font-mono">{formatTime(timeLeft)}</span>
        </div>
      </div>

      <div className="p-6 bg-gray-50 rounded-lg">
        <p className="text-lg font-medium mb-6">{question.text}</p>
        <div className="space-y-3">
          {question.options.map((option, index) => (
            <button
              key={index}
              onClick={() => onAnswerSelect(index)}
              className={`w-full p-4 text-left rounded-lg transition-colors ${
                selectedAnswer === index
                  ? 'bg-indigo-600 text-white'
                  : 'bg-white hover:bg-gray-100'
              }`}
            >
              {option}
            </button>
          ))}
        </div>
      </div>

      <div className="flex justify-between items-center">
        <button
          onClick={onPrevious}
          disabled={questionNumber === 1}
          className="px-4 py-2 text-gray-600 hover:text-gray-800 disabled:opacity-50"
        >
          Previous
        </button>
        
        {questionNumber === totalQuestions ? (
          <button
            onClick={onSubmit}
            className="px-6 py-2 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700"
          >
            Submit Exam
          </button>
        ) : (
          <button
            onClick={onNext}
            className="px-4 py-2 text-indigo-600 hover:text-indigo-800"
          >
            Next
          </button>
        )}
      </div>
    </div>
  );
}