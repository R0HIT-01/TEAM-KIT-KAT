export interface Question {
  id: string;
  text: string;
  options: string[];
  correct_answer: number;
  explanation: string;
  difficulty: 'easy' | 'medium' | 'hard';
  subject: string;
  topic: string;
}

export interface ExamState {
  currentQuestion: number;
  selectedAnswers: number[];
  timeLeft: number;
  examCompleted: boolean;
  showExplanation: boolean;
  examStarted: boolean;
}