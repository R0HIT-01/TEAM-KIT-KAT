import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { useUserStore } from '../../store/userStore';
import { ExamIntro } from './exam/ExamIntro';
import { ExamQuestion } from './exam/ExamQuestion';
import { ExamResults } from './exam/ExamResults';
import { mockQuestions } from './exam/mockData';
import type { ExamState } from './exam/types';

const initialState: ExamState = {
  currentQuestion: 0,
  selectedAnswers: [],
  timeLeft: 7200, // 2 hours
  examCompleted: false,
  showExplanation: false,
  examStarted: false,
};

export function ExamSimulation() {
  const [state, setState] = useState<ExamState>(initialState);
  const { addPracticeTest } = useUserStore();

  useEffect(() => {
    if (state.examStarted && state.timeLeft > 0 && !state.examCompleted) {
      const timer = setInterval(() => {
        setState((prev) => ({
          ...prev,
          timeLeft: prev.timeLeft <= 1 ? 0 : prev.timeLeft - 1,
          examCompleted: prev.timeLeft <= 1,
        }));
      }, 1000);
      return () => clearInterval(timer);
    }
  }, [state.examStarted, state.timeLeft, state.examCompleted]);

  const handleStartExam = () => {
    setState((prev) => ({ ...prev, examStarted: true }));
  };

  const handleAnswerSelect = (optionIndex: number) => {
    setState((prev) => {
      const newAnswers = [...prev.selectedAnswers];
      newAnswers[prev.currentQuestion] = optionIndex;
      return { ...prev, selectedAnswers: newAnswers };
    });
  };

  const handleSubmit = async () => {
    const score = state.selectedAnswers.reduce((acc, answer, index) => {
      return acc + (answer === mockQuestions[index].correct_answer ? 1 : 0);
    }, 0);

    try {
      await addPracticeTest({
        subject: 'UPSC Mock Exam',
        score,
        total_questions: mockQuestions.length,
        time_taken: 7200 - state.timeLeft,
      });
      setState((prev) => ({ ...prev, examCompleted: true }));
    } catch (error) {
      console.error('Failed to save practice test:', error);
      // Handle error appropriately
    }
  };

  if (!state.examStarted) {
    return <ExamIntro onStart={handleStartExam} />;
  }

  if (state.examCompleted) {
    return (
      <ExamResults
        questions={mockQuestions}
        selectedAnswers={state.selectedAnswers}
        onRetake={() => setState(initialState)}
      />
    );
  }

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="bg-white rounded-xl shadow-lg p-6 max-w-4xl mx-auto"
    >
      <ExamQuestion
        question={mockQuestions[state.currentQuestion]}
        questionNumber={state.currentQuestion + 1}
        totalQuestions={mockQuestions.length}
        selectedAnswer={state.selectedAnswers[state.currentQuestion]}
        timeLeft={state.timeLeft}
        onAnswerSelect={handleAnswerSelect}
        onNext={() => setState(prev => ({ ...prev, currentQuestion: prev.currentQuestion + 1 }))}
        onPrevious={() => setState(prev => ({ ...prev, currentQuestion: prev.currentQuestion - 1 }))}
        onSubmit={handleSubmit}
      />
    </motion.div>
  );
}